#include <stdio.h>

#include "vmss_bitfields.h"

int main (int argc, const char * argv[]) {

	
	return 0;
}

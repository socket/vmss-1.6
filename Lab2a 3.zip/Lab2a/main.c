#include <stdio.h>

#include "vmss_common.h"
#include "vmss_convert.h"
#include "vmss_bitfields.h"

int main (int argc, const char * argv[]) {
	char buffer[256];
	char *pb = buffer;
	FILE* hsrc = fopen("INPUT.txt", "r");
	
	if ( !hsrc ) {
		printf("Cannot open input file\n");
		return -1;
	}
	
	int bitcount = BIT_COUNT - 1;
	
	while (pb = fgets(buffer, 256, hsrc) ) {
		char *left, *right;
		vmss_strchop(pb);

		left = right = pb;
		while(*right && *right != ':') right++;
		*right++ = '\0';
		
		// convert dec to bin
		printf("%s / %s =>", left, right);
		char binleft[128];
		char binright[128];
		
		if ( SUCCESS( vmss_str2number(left, 10, 2, binleft, bitcount))  && SUCCESS( vmss_str2number(right, 10, 2, binright, bitcount) ) ) {
			char binres[128], binresdec[128], binreshex[128];
			INTFIELD src, del;

			string2bits(binleft, &src);
			string2bits(binright, &del);
			shift_right(&src);
			shift_right(&del);
			printf("DIV: %s / ", bits2string(&src));
			printf("%s\n", bits2string(&del));
			divide_dc(&src, &del, binres);
			
			printf("BIN: %s\n", binres);

			vmss_str2number(binres, 2, 10, binresdec, BIT_COUNT);
			
			divide_dc(&src, &del, binres);
			vmss_str2number(binres, 2, 16, binreshex, BIT_COUNT);
			
			printf(" %s [%s]", binresdec, binreshex);
		}
		else {
			printf("INVALID");
		}
		printf("\n");
	}
	
	fclose(hsrc);
	
	return 0;
}
